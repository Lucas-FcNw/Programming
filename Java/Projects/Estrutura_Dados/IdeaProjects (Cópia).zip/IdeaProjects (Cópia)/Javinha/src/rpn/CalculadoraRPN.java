/*
* Caio Henrique Santos Carvalho RA: 10425408
* Diogo Fassina Garcia - RA: 10417030
* Rafael de Souza Alves de Lima RA: 10425819
* Lucas Fernandes de Camargo RA: 10419400
*
*
*
*
* Projeto feio no ambiente Intellij em um sistema Fedora (dnf)
* */

package rpn;

import rpn.service.REPL;

public class CalculadoraRPN {
    public static void main(String[] args) {
        new REPL().iniciar(); //Inicia o """GRUB"""
    }
}